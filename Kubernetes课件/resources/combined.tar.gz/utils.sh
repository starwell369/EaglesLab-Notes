#!/bin/bash

# 导入日志模块
source $(dirname "$0")/logger.sh

# 验证IP地址格式
validate_ip() {
    local ip=$1
    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        for i in {1..4}; do
            if [ $(echo "$ip" | cut -d. -f$i) -gt 255 ]; then
                return 1
            fi
        done
        return 0
    else
        return 1
    fi
}

# 解压压缩包至/tmp/目录
extract_archive() {
    local archive_file=$1
    local extract_dir=/tmp/$(basename $1 .tar.gz)-$(date +%s)
    
    # 检查tar命令是否可用
    if ! command -v tar &>/dev/null; then
        log_error "tar命令未找到，请确保tar已安装"
        return 1
    fi
    
    # 检查压缩包是否存在并可读
    if ! check_archive "$archive_file"; then
        return 1
    fi
    
    # 如果指定了解压目录，创建它
    if [ "$extract_dir" != "." ]; then
        mkdir -p "$extract_dir"
    fi

    if ! tar -zxvf "$archive_file" -C "$extract_dir" > /dev/null 2>&1; then
        log_error "解压压缩包 '$archive_file' 失败"
        return 1
    fi
    log_info "解压成功，文件已解压到 '$extract_dir'"
    echo "$extract_dir"
}