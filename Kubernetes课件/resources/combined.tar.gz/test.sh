#!/bin/bash

# 导入日志模块和检查工具模块
source $(dirname "$0")/logger.sh
source $(dirname "$0")/check_utils.sh
source $(dirname "$0")/utils.sh

tmp=$(extract_archive "$1")
if [ $? -ne 0 ]; then
    log_error "解压文件 $1 失败"
    exit 1
fi
log_info "解压成功，临时目录为: $temp_dir"
