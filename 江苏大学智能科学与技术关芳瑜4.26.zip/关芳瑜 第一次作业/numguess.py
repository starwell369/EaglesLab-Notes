import random
print('猜数字游戏开始')
num=random.randint(1,101)
for i in range(1,4):
    guess = int(input("您猜数字是什么？(输入0-100的数字):"))
    if guess < num:
        print("您猜小了")
        continue
    elif guess > num:
        print("您猜大了")
        continue
    break
if guess == num:
    print("您猜对了！")
else:
    print("Game over!")


