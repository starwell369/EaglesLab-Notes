db = {}
with open('E:\my tests\pythonhomework\sql.txt', 'r', encoding='utf-8')as f:
    data = f.readlines()
    print(data)
    for i in data:
        ret = i.strip().split("|")
        # ret = ["张三", "123"]
        print(ret)
        db[ret[0]] = ret[1]
        # db["张三"] = "123"
        print(db)
i=0
while True:
    print("是否注册？")
    choise=input()
    if choise=="是":
        name=input("请输入用户名：")
        db[name]=name
        newword=input("请输入密码：")
        db[name]=newword
    if choise=='否':
        username = input("请输入用户名：")

    if username in db:
        password = input("请输入密码：")
        if password == db[username]:
            print("登录成功")
            break
        else:
            print("密码错误登录失败")
            i=i+1
    else:
        print("用户名不存在")
    if(i==3):
        print("封号")
        break