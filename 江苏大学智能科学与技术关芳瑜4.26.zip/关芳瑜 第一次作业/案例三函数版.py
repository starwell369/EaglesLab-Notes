import json
from pathlib import Path

def load_data(file_path):
    """从文件加载用户数据"""
    try:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    except Exception as e:
        print(f"读取文件错误: {e}")
        return {}

def save_data(file_path, data):
    """将用户数据保存到文件"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"保存文件错误: {e}")

def register_user(db):
    """处理用户注册"""
    name = input("请输入用户名：").strip()
    if not name:
        print("用户名不能为空")
        return False
    if name in db:
        print("用户名已存在")
        return False
    password = input("请输入密码：").strip()
    if not password:
        print("密码不能为空")
        return False
    db[name] = password
    print(f"用户 {name} 注册成功")
    return True

def login_user(db, max_attempts=3):
    """处理用户登录"""
    attempts = 0
    while attempts < max_attempts:
        username = input("请输入用户名：").strip()
        if username not in db:
            print("用户名不存在")
            attempts += 1
            continue
        password = input("请输入密码：").strip()
        if password == db[username]:
            print("登录成功")
            return True
        else:
            print("密码错误")
            attempts += 1
    print(f"尝试次数过多，账号已锁定")
    return False

def main():
    """主函数，程序入口点"""
    file_path = Path(r'E:\my tests\pythonhomework\sql.txt')
    
    # 确保目录存在
    file_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 加载数据库
    db = load_data(file_path)
    
    while True:
        print("\n欢迎使用用户系统")
        print("1. 注册")
        print("2. 登录")
        print("3. 退出")
        
        choice = input("请选择操作 (1-3): ").strip()
        
        if choice == '1':
            if register_user(db):
                save_data(file_path, db)  # 注册成功后保存数据
        elif choice == '2':
            if login_user(db):
                break  # 登录成功则退出循环
        elif choice == '3':
            print("再见！")
            break
        else:
            print("无效选择，请重新输入")

if __name__ == "__main__":
    main()