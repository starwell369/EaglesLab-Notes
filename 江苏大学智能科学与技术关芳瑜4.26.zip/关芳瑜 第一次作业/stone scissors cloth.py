import random
# random产生随机值或者从给定值中随机选择

# 可选择的选项
options = ["石头", "剪子", "布"]
score1=0
score2=0
for i in range(1,4):
    print("欢迎来到石头剪子布游戏！")
    print("请从以下选项中选择：")
    for i, option in enumerate(options):
        print(f"{i + 1}. {option}")

# 玩家选择
    player_choice = int(input("请输入你的选择（1-3）：")) - 1

# 计算机随机选择
    computer_choice = random.randint(0, 2)

    print(f"\n你选择了：{options[player_choice]}")
    print(f"计算机选择了：{options[computer_choice]}")

# 判断胜负
    if player_choice == computer_choice:
        print("平局！")
    elif (player_choice == 0 and computer_choice == 1) or \
         (player_choice == 1 and computer_choice == 2) or \
        (player_choice == 2 and computer_choice == 0):
        print("你赢了！🎉")
        score1+=1
    else:
        print("你输了！😢")
        score2+=1
print("您的得分是：",score1)
print("计算机的得分是：",score2)
if(score1>score2):
    print("您是最后的赢家！")
if(score1<score2):
    print("很遗憾，继续努力吧！")